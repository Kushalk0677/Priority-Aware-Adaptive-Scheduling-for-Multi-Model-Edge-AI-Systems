# Intel Core Ultra 5 125H

This folder contains v2 result artifacts for Intel Core Ultra 5 125H.

Key metrics from `summary_v2.json`:
- PAES avg wait: 108.82
- FIFO avg wait: 128.9
- Est.-SJF avg wait: 102.18
- PAES priority-weighted wait: 89.78
- PAES vs FIFO queue-wait improvement: 15.58%
- PAES miss rate (exp1): 0.0
- PAES high-load miss rate (exp2): 0.0

Primary files:
- `exp1_latency_v2.csv`
- `exp1_wilcoxon_v2.csv`
- `exp2_deadline_v2.csv`
- `exp3_energy_v2.csv`
- `exp4_burst_v2.csv`
- `exp5_sensitivity_v2.csv`
- `summary_v2.json`
