# i7-1165G7

This folder contains v2 result artifacts for i7-1165G7.

Key metrics from `summary_v2.json`:
- PAES avg wait: 10685.0
- FIFO avg wait: 14369.21
- Est.-SJF avg wait: 4329.36
- PAES priority-weighted wait: 7257.93
- PAES vs FIFO queue-wait improvement: 25.64%
- PAES miss rate (exp1): 0.95
- PAES high-load miss rate (exp2): 0.9625

Primary files:
- `exp1_latency_v2.csv`
- `exp1_wilcoxon_v2.csv`
- `exp2_deadline_v2.csv`
- `exp3_energy_v2.csv`
- `exp4_burst_v2.csv`
- `exp5_sensitivity_v2.csv`
- `summary_v2.json`
