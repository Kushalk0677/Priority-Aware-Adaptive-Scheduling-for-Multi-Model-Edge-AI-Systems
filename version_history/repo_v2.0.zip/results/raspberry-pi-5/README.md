# Raspberry Pi 5 (Cortex-A76 @ 2.4GHz)

This folder contains v2 result artifacts for Raspberry Pi 5 (Cortex-A76 @ 2.4GHz).

Key metrics from `summary_v2.json`:
- PAES avg wait: 423.62
- FIFO avg wait: 512.37
- Est.-SJF avg wait: 396.27
- PAES priority-weighted wait: 346.62
- PAES vs FIFO queue-wait improvement: 17.32%
- PAES miss rate (exp1): 0.41
- PAES high-load miss rate (exp2): 0.0

Primary files:
- `exp1_latency_v2.csv`
- `exp1_wilcoxon_v2.csv`
- `exp2_deadline_v2.csv`
- `exp3_energy_v2.csv`
- `exp4_burst_v2.csv`
- `exp5_sensitivity_v2.csv`
- `summary_v2.json`
