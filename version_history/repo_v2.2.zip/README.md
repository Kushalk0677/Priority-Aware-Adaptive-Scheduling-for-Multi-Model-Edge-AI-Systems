# PAES organized repository

This repo combines the **paper-aligned artifacts from repo_v1.0** with the
**extended v2 code and additions from repo_v2.0**.

## Repository layout

### `results/main/`
This is the **canonical paper artifact set**.

These files correspond to the published paper tables and figures for the
shared devices:

- `i7-1165G7`
- `core-ultra-5`
- `raspberry-pi-5`

Included per device:

- `exp1_latency.csv`
- `exp2_deadline.csv`
- `exp3_energy.csv`
- `exp4_burst.csv`
- `exp5_sensitivity.csv`
- `exp_overhead.csv`
- `exp_workload_realism.csv`

### `results/v2_additions/`
This contains the **newer v2-only outputs** layered on top of the paper set:

- `*_v2.csv`
- `exp1_wilcoxon_v2.csv`
- `summary_v2.json`
- arrival-sensitivity outputs
- extra device results such as `core-ultra-9` and `i5-520m`

## Linked paper mapping

The file `PAPER_REPRODUCIBILITY.md` and `results/PAPER_TO_RESULTS_MAP.json`
link each paper table/figure to the corresponding artifact file.

Quick lookup for the primary paper device (`i7-1165G7`):

- Table II / Figure 2 → `results/main/i7-1165G7/exp1_latency.csv`
- Table III / Figure 3 → `results/main/i7-1165G7/exp2_deadline.csv`
- Table IV / Figure 4 → `results/main/i7-1165G7/exp3_energy.csv`
- Table V / Figure 5 → `results/main/i7-1165G7/exp4_burst.csv`
- Table VI / Figure 6 → `results/main/i7-1165G7/exp5_sensitivity.csv`
- Table VII / Figure 8 → `results/main/i7-1165G7/exp_overhead.csv`
- Table VIII / Figure 9 → `results/main/i7-1165G7/exp_workload_realism.csv`

## Entry points

### `run_all.py`
Unified top-level entry point.

#### Show the linked paper artifacts

```bash
python run_all.py --paper --use-stored
```

#### Verify that the canonical paper artifact set exists

```bash
python run_all.py --paper --verify
```

#### Print exact full-mode regeneration commands

```bash
python run_all.py --paper --print-commands --device i7-1165G7
```

### `run_all_v2.py`
Working **extended synthetic v2 suite**.

```bash
python run_all_v2.py
python run_all_v2.py --quick
python run_all_v2.py --exp 1 2 3 4 5 6
```

Notes:
- full mode defaults to `tasks=300`, `repeats=10`
- quick mode uses reduced counts for validation
- includes the explicit `estimated_sjf` 8th baseline and other v2 additions
- outputs are part of the **extended v2** surface, not the canonical paper set

### `run_real_device.py`
Working **full real-device runner** for the final v2 scheduler/metrics.

```bash
python run_real_device.py
python run_real_device.py --quick
python run_real_device.py --repeats 10 --exp 1 2 3 4 5 6 7
```

Notes:
- full mode defaults to `tasks=600`
- experiment `7` is the robot pipeline / workload realism run
- uses the corrected deadline metric and v2 scheduler fixes

### `exp_overhead.py`
Standalone scheduler-overhead experiment.

```bash
python exp_overhead.py
```

## Full paper-mode regeneration

The paper uses **full mode**, not quick mode.

To regenerate the paper-style experiment bundle for a device:

```bash
python run_real_device.py --repeats 10 --exp 1 2 3 4 5 6 7 --device i7-1165G7
python exp_overhead.py
```

Keep the checked-in `results/main/` files as the **canonical paper ground truth**.
Use fresh reruns for comparison rather than overwriting the stored artifacts.

## Original READMEs

- `README_v1_original.md`
- `README_v2_original.md`
