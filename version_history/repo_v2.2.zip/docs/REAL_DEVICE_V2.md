# PAES v2 — Real Device Experiments

Run these experiments on any physical device to reproduce or extend
the PAES paper results with v2 fixes.

## What's new in v2

| Fix | Description |
|-----|-------------|
| [1] | `deadline_missed` uses `queue_wait + inference` vs deadline — not inference alone |
| [2] | `priority_weighted_avg_wait_ms` — YOLOv5 (pri=3.0) counts 3x more than MiDaS (pri=1.0) |
| [3] | PAES deadline proximity bonus — urgency spike within θ=150ms of deadline |
| [4] | `per_model_stats()` includes `avg_wait_ms` per model — PM vs servant breakdown |

## Files

```
real_device_v2/
├── run_real_device.py   ← main entry point
├── scheduler.py         ← v2 scheduler with all fixes
├── model_zoo.py         ← real model wrappers + calibrated fallbacks
└── README.md
```

## Setup

```bash
pip install numpy pandas matplotlib tqdm scipy

# For real inference (recommended):
pip install torch torchvision     # MobileNetV2, YOLOv5n, MiDaS
pip install ultralytics           # YOLOv5n
pip install openai-whisper        # Whisper Tiny
pip install transformers          # DistilBERT
```

Python 3.10+ required.

## Usage

```bash
# Full run — all 7 experiments, 10 repeats, 600 tasks
python run_real_device.py

# Quick validation — reduced counts
python run_real_device.py --quick

# Specific experiments only
python run_real_device.py --exp 1 2 6

# Custom device name for output folder
python run_real_device.py --device jetson_orin

# More repeats for publication
python run_real_device.py --repeats 20
```

## Experiments

| # | Name | Description |
|---|------|-------------|
| 1 | Latency & Queue Wait | 600 tasks, all 7 schedulers, unweighted + priority-weighted wait |
| 2 | Miss Rate vs Load | low/medium/high/extreme load levels |
| 3 | Energy per Task | TDP-proxy energy comparison |
| 4 | Burst Recovery | pre-burst → burst → post-burst miss rate |
| 5 | Sensitivity | α/β/γ weight sweep |
| 6 | Per-Model Wait *(new)* | PM vs servant breakdown — PAES vs FIFO per model |
| 7 | Robot Pipeline | 30s realistic heterogeneous pipeline, 685 tasks |

## Output

Results are saved to `results/<device_name>/`:

```
exp1_latency.csv
exp2_deadline.csv
exp3_energy.csv
exp4_burst.csv
exp5_sensitivity.csv
exp_per_model_wait.csv    ← new in v2
exp_workload_realism.csv
summary_v2.json
```

## Hardware boundary conditions

| Device type | Expected behaviour |
|-------------|-------------------|
| High-end (24+ cores, >5GHz) | All schedulers converge — scheduling order irrelevant |
| Mid-range (4-14 cores) | PAES shows strongest gains — productive operating range |
| Constrained ARM (RPi5) | Queue drains as fast as tasks arrive — near-zero wait |
| Legacy/saturated | >30% miss rate across all schedulers regardless of policy |

## Key finding (v2)

The unweighted `avg_wait_ms` masks per-priority behaviour.
`priority_weighted_avg_wait_ms` and the per-model breakdown (Exp 6)
reveal that PAES systematically reduces wait for high-priority tasks
(YOLOv5: ~80% reduction) at the cost of low-priority tasks
(MiDaS: ~80% increase). This is correct behaviour — but was invisible
in the original paper's headline metric.
