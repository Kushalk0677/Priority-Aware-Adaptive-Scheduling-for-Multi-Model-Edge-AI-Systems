# PAES v2 repository

This repository contains the working PAES v2 experiment code, updated scheduler, and real-device runner.

## Main entry points

### Synthetic / simulator-backed experiment suite
Use `run_all.py` to run the main PAES v2 experiment suite.

```bash
python run_all.py
python run_all.py --quick
python run_all.py --exp 1 2 6
python run_all.py --device i7-1165G7
```

Notes:
- Full mode defaults to `repeats=10`, `tasks=300` unless overridden.
- Quick mode reduces runtime for validation by patching simulator timing and setting `tasks=200`, `repeats=3`. 
- `run_all.py` runs experiments 1–6.

### Real-device experiment suite
Use `run_real_device.py` for physical-device runs.

```bash
python run_real_device.py
python run_real_device.py --quick
python run_real_device.py --exp 1 2 3 4 5 6 7
python run_real_device.py --repeats 10
```

Notes:
- Full mode defaults to `tasks=600` per experiment.
- Quick mode uses `tasks=200`, `repeats=2`.
- Experiment `7` is the robot pipeline / workload-realism run.

## Included v2 fixes

- Deadline misses use **total response time** (`queue_wait + inference`) rather than inference alone.
- Priority-weighted average queue wait is reported.
- PAES includes a deadline-proximity bonus near deadline expiry.
- Per-model wait analysis is supported.
- Estimated-SJF is included as an explicit baseline in the v2 synthetic experiment suite.

## Included files

- `run_all.py` — working synthetic PAES v2 experiment runner
- `run_real_device.py` — working physical-device runner
- `scheduler.py` — v2 scheduler implementation
- `experiments.py` — v2 synthetic experiment suite
- `exp_overhead.py` — scheduler overhead benchmark
- `exp_workload_realism.py` — structured workload script
- `RESULTS_V2_ALL_DEVICES.md` — aggregate v2 results overview
- `docs/REAL_DEVICE_V2.md` — real-device notes

## Outputs

Typical outputs are written under:

- `results/<device>/...`
- `figures/<device>/...`

Main summary files:

- `results/<device>/summary_v2.json`
- `results/<device>/exp1_latency*.csv`
- `results/<device>/exp2_deadline*.csv`
- `results/<device>/exp3_energy*.csv`
- `results/<device>/exp4_burst*.csv`
- `results/<device>/exp5_sensitivity*.csv`
- `results/<device>/exp6_arrival_sensitivity_v2.csv` or `exp_per_model_wait.csv` depending on runner
- `results/<device>/exp_workload_realism.csv` for robot pipeline runs
