# PAES v2 — Complete Results (All 5 Devices)

## Devices

| Folder | Device | Mode | Repeats |
|--------|--------|------|---------|
| `i7-1165G7/` | Intel Core i7-1165G7 (HP Spectre x360) | Quick mode (×4.685 scaled) | 3 |
| `raspberry-pi-5/` | Raspberry Pi 5 (Cortex-A76 @ 2.4GHz) | Real inference | 10 |
| `core-ultra-5/` | Intel Core Ultra 5 125H | Real inference | 10 |
| `core-ultra-9/` | Intel Core Ultra 9 285H | Real inference | 10 |
| `i5-520m/` | Intel Core i5-520M (2010, legacy) | Simulation only | — |

**Note on i7:** Run in quick mode (time.sleep × 1/100). Queue wait values
scaled by 4.685× (anchored to paper FIFO value of 67,322ms). Wilcoxon
p-values not valid (only 3 repeats). Re-run with `--repeats 10` for
publication-quality statistics.

**Note on i5-520M:** Compute-saturated boundary condition. Inference alone
exceeds deadlines regardless of scheduling policy. Simulation only.

## Files per device

| File | Contents |
|------|----------|
| `exp1_latency_v2.csv` | Avg/p50/p95/p99 latency, queue wait, priority-weighted wait, miss rate — all 8 schedulers |
| `exp1_wilcoxon_v2.csv` | Wilcoxon p-values: PAES vs each baseline on queue wait |
| `exp2_deadline_v2.csv` | Miss rate at low/medium/high/extreme load |
| `exp3_energy_v2.csv` | Energy per task (TDP-proxy) |
| `exp4_burst_v2.csv` | Burst workload recovery |
| `exp5_sensitivity_v2.csv` | α/β/γ weight sweep |
| `exp6_arrival_v2.csv` | Arrival distribution sensitivity (uniform/Poisson/bursty) |
| `summary_v2.json` | Key metrics summary |

## Figures

| Figure | Description |
|--------|-------------|
| `fig_queue_wait_all_devices.png` | Raw avg queue wait — all 8 schedulers, all 5 devices |
| `fig_pw_wait_all_devices.png` | Priority-weighted avg queue wait — all 8 schedulers |
| `fig_miss_rate_all_devices.png` | Miss rate vs load level — 4 real devices |
| `fig_wilcoxon_pvalues.png` | Wilcoxon p-value heatmap (RPi5, Ultra5, Ultra9) |
| `fig_paes_vs_sjf.png` | Raw vs priority-weighted wait: PAES vs Est.-SJF vs FIFO |
| `fig_per_model_wait.png` | Per-model wait heatmap: FIFO vs PAES |

## Key findings

**PAES vs FIFO (queue wait, real inference):**
- i7-1165G7 (scaled): −25.6%
- Raspberry Pi 5:     −17.3%  (p=0.002)
- Core Ultra 5:       −15.6%  (p=0.002)
- Core Ultra 9:       −28.4%  (p=0.002)

**Est.-SJF vs PAES (raw queue wait):**
Est.-SJF beats PAES on raw queue wait on all devices (p≤0.002).
PAES beats Est.-SJF on priority-weighted wait — this is PAES's true
advantage: it protects high-priority tasks at the cost of low-priority
deferral, which the unweighted average was hiding.

**Wilcoxon summary (RPi5, Ultra5, Ultra9 — 10 repeats each):**
- PAES vs FIFO/RR/SP/QoS: p=0.002 (significant) on all 3 devices
- PAES vs EDF: p=0.85/1.0 on RPi5/Ultra5 (comparable), p=0.01 on Ultra9
- PAES vs Est.-SJF: p=0.002/0.01 (Est.-SJF wins raw wait, significant)
