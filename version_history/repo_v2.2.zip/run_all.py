#!/usr/bin/env python3
"""
PAES unified entry point.

Modes:
  1) Paper mode: show / verify / scaffold the exact paper artifact mapping.
  2) Extended v2 mode: pass through to run_all_v2.py.
  3) Real-device mode: pass through to run_real_device.py.
"""
from __future__ import annotations
import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
MAIN = RESULTS / "main"
V2 = RESULTS / "v2_additions"

CANONICAL_FILES = {
    "i7-1165G7": [
        "exp1_latency.csv",
        "exp2_deadline.csv",
        "exp3_energy.csv",
        "exp4_burst.csv",
        "exp5_sensitivity.csv",
        "exp_overhead.csv",
        "exp_workload_realism.csv",
    ],
    "core-ultra-5": [
        "exp1_latency.csv",
        "exp2_deadline.csv",
        "exp3_energy.csv",
        "exp4_burst.csv",
        "exp5_sensitivity.csv",
        "exp_overhead.csv",
        "exp_workload_realism.csv",
    ],
    "raspberry-pi-5": [
        "exp1_latency.csv",
        "exp2_deadline.csv",
        "exp3_energy.csv",
        "exp4_burst.csv",
        "exp5_sensitivity.csv",
        "exp_overhead.csv",
        "exp_workload_realism.csv",
    ],
}

PAPER_MAP = {
    "Table II / Figure 2": "results/main/i7-1165G7/exp1_latency.csv",
    "Table III / Figure 3": "results/main/i7-1165G7/exp2_deadline.csv",
    "Table IV / Figure 4": "results/main/i7-1165G7/exp3_energy.csv",
    "Table V / Figure 5": "results/main/i7-1165G7/exp4_burst.csv",
    "Table VI / Figure 6": "results/main/i7-1165G7/exp5_sensitivity.csv",
    "Table VII / Figure 8": "results/main/i7-1165G7/exp_overhead.csv",
    "Table VIII / Figure 9": "results/main/i7-1165G7/exp_workload_realism.csv",
    "Cross-device paper artifacts": "results/main/{core-ultra-5,raspberry-pi-5}/...",
    "Extended v2-only additions": "results/v2_additions/...",
}


def print_paper_links() -> None:
    print("\nPAES paper linkage")
    print("=" * 72)
    for k, v in PAPER_MAP.items():
        print(f"- {k:<32} -> {v}")
    print("=" * 72)
    print("\nCanonical paper artifacts are stored under results/main/.")
    print("Extended v2 artifacts are stored under results/v2_additions/.")


def verify_main() -> int:
    print("\nVerifying canonical paper artifacts...")
    missing = []
    for device, files in CANONICAL_FILES.items():
        for fname in files:
            path = MAIN / device / fname
            if not path.exists():
                missing.append(str(path.relative_to(ROOT)))
    if missing:
        print("\nMissing files:")
        for m in missing:
            print(f"- {m}")
        return 1
    print("All canonical paper artifacts are present.")
    return 0


def print_commands(device: str) -> None:
    print("\nPaper-mode regeneration commands")
    print("=" * 72)
    print("# Real-device / full-mode paper bundle")
    print(f"python run_real_device.py --repeats 10 --exp 1 2 3 4 5 6 7 --device {device}")
    print("python exp_overhead.py")
    print("\n# Extended synthetic v2 suite (separate from canonical paper outputs)")
    print(f"python run_all_v2.py --device {device} --tasks 300 --repeats 10 --exp 1 2 3 4 5 6")
    print("=" * 72)


def passthrough(script: str, extra_args: list[str]) -> int:
    cmd = [sys.executable, str(ROOT / script), *extra_args]
    return subprocess.call(cmd, cwd=str(ROOT))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--paper", action="store_true", help="paper-oriented mode")
    parser.add_argument("--use-stored", action="store_true", help="show linked stored paper artifacts")
    parser.add_argument("--verify", action="store_true", help="verify canonical paper artifacts exist")
    parser.add_argument("--print-commands", action="store_true", help="print full paper-mode rerun commands")
    parser.add_argument("--device", default="i7-1165G7")
    parser.add_argument("--mode", choices=["v2", "real"], help="run extended v2 or real-device runner")
    args, rest = parser.parse_known_args()

    if args.paper:
        print_paper_links()
        rc = 0
        if args.verify:
            rc = verify_main() or rc
        if args.print_commands or args.use_stored or (not args.verify and not args.print_commands and not args.mode):
            print_commands(args.device)
            print("\nUse --use-stored to treat results/main as the canonical paper output set.")
        if args.mode == "v2":
            return passthrough("run_all_v2.py", rest)
        if args.mode == "real":
            return passthrough("run_real_device.py", rest)
        return rc

    if args.mode == "v2":
        return passthrough("run_all_v2.py", rest)
    if args.mode == "real":
        return passthrough("run_real_device.py", rest)

    print("PAES unified runner")
    print("- Canonical paper artifacts: results/main/")
    print("- Extended v2 additions:     results/v2_additions/")
    print("\nExamples:")
    print("  python run_all.py --paper --use-stored")
    print("  python run_all.py --paper --verify")
    print("  python run_all.py --paper --print-commands --device i7-1165G7")
    print("  python run_all.py --mode v2 -- --quick")
    print("  python run_all.py --mode real -- --quick")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
