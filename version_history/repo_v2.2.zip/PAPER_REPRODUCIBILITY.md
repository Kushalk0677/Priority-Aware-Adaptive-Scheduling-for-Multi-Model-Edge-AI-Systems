
# Paper reproducibility guide

## Canonical paper artifacts

The paper-faithful artifacts live under `results/main/`.

For the primary device used in the paper (`i7-1165G7`), the canonical files are:

- `results/main/i7-1165G7/exp1_latency.csv` → Table II / Figure 2
- `results/main/i7-1165G7/exp2_deadline.csv` → Table III / Figure 3
- `results/main/i7-1165G7/exp3_energy.csv` → Table IV / Figure 4
- `results/main/i7-1165G7/exp4_burst.csv` → Table V / Figure 5
- `results/main/i7-1165G7/exp5_sensitivity.csv` → Table VI / Figure 6
- `results/main/i7-1165G7/exp_overhead.csv` → Table VII / Figure 8
- `results/main/i7-1165G7/exp_workload_realism.csv` → Table VIII / Figure 9

## Extended v2 artifacts

The newer v2-only outputs live under `results/v2_additions/`.
These include:

- `*_v2.csv`
- `summary_v2.json`
- Wilcoxon outputs
- arrival sensitivity outputs
- extra devices not included in the paper-faithful main set

## Commands

### Show paper mapping without running anything

```bash
python run_all.py --paper --use-stored
```

### Verify that the expected canonical files exist

```bash
python run_all.py --paper --verify
```

### Generate a fresh paper-style run scaffold

```bash
python run_all.py --paper --device i7-1165G7 --print-commands
```

This prints the exact commands to regenerate the paper experiments in full mode.

### Run the full real-device paper experiment bundle

```bash
python run_real_device.py --repeats 10 --exp 1 2 3 4 5 6 7 --device i7-1165G7
python exp_overhead.py
```

Note: the checked-in `results/main/` remains the canonical paper artifact set.
Fresh reruns should be compared against those files rather than overwriting them.
