# PAES organized repository

This repo combines the **paper-aligned artifacts from repo_v1.0** with the
**extended v2 code and additions from repo_v2.0**.

## How this repo is organized

### `results/main/`
Paper-aligned results that are identical between `repo_v1.0` and `repo_v2.0`.
These are the artifacts that correspond to the paper tables/figures for the
shared devices:

- `i7-1165G7`
- `core-ultra-5`
- `raspberry-pi-5`

Included files per device:

- `exp1_latency.csv`
- `exp2_deadline.csv`
- `exp3_energy.csv`
- `exp4_burst.csv`
- `exp5_sensitivity.csv`
- `exp_overhead.csv`
- `exp_workload_realism.csv`

### `results/v2_additions/`
Newer v2 additions layered on top of the paper artifacts:

- `*_v2.csv` outputs
- `exp1_wilcoxon_v2.csv`
- `summary_v2.json`
- extended device results (`core-ultra-9`, `i5-520m`)

## Entry points

### `run_all_v2.py`
Working synthetic v2 suite. Runs experiments 1–6 with the extended v2 setup.

```bash
python run_all_v2.py
python run_all_v2.py --quick
python run_all_v2.py --exp 1 2 3 4 5 6
```

Notes:
- full mode defaults to `tasks=300`, `repeats=10`
- quick mode uses reduced counts for validation
- includes the explicit `estimated_sjf` 8th baseline and other v2 additions

### `run_real_device.py`
Working real-device runner for the final v2 scheduler/metrics.

```bash
python run_real_device.py
python run_real_device.py --quick
python run_real_device.py --repeats 10 --exp 1 2 3 4 5 6 7
```

Notes:
- full mode defaults to `tasks=600`
- experiment `7` is the robot pipeline / workload realism run
- uses the corrected deadline metric and v2 scheduler fixes

### `run_all.py`
A lightweight helper that points you to the correct runner and the organized
results layout.

## Notes on reproducibility

- The **stored results in `results/main/`** are the paper-aligned artifacts.
- The **working v2 runners** are in `run_all_v2.py` and `run_real_device.py`.
- The synthetic v2 runner is broader than the paper surface (it adds an 8th
  baseline and new analyses), so its default outputs are kept under
  `results/v2_additions/` in this organized repo.

## Original READMEs

- `README_v1_original.md`
- `README_v2_original.md`
