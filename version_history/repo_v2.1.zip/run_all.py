"""
run_all.py
=========
Paper-oriented entry point for the organized PAES repository.

This wrapper keeps the repo focused on the published paper artifacts.
For the extended v2 synthetic suite (8 schedulers, Wilcoxon tests,
arrival sensitivity, *_v2 outputs), use:

    python run_all_v2.py ...

For real-device / 600-task runs and robot pipeline experiments, use:

    python run_real_device.py ...
"""

from pathlib import Path
import sys

print("PAES organized repo")
print("- Paper-aligned stored results: results/main/")
print("- Extended v2 additions:        results/v2_additions/")
print("- Use run_all_v2.py for the extended synthetic v2 suite")
print("- Use run_real_device.py for full 600-task / robot-pipeline runs")
print()
print("Examples:")
print("  python run_all_v2.py --quick")
print("  python run_all_v2.py --exp 1 2 3 4 5 6")
print("  python run_real_device.py --repeats 10 --exp 1 2 3 4 5 6 7")
